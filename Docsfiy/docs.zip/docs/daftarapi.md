# Cara Mendaftar API ke JuraganCOD
API digunakan untuk menghubungkan website anda dengan fitur JuraganCOD.
>Yang anda perlukan untuk mendapatkan API:
````
1. Mendaftar di JuraganCOD.com
2. Memverifikasi akun anda
3. Buka setting
4. Open API Key
````
## Mendaftar di JuraganCOD
- Silahkan akses <b>JuraganCOD.com</b>
- Klik <b>Daftar</b>
- Isi form pendaftaran
- Tunggu OTP dan isi OTP
- Upload foto KTP dan isi detail perbankan anda
- Tunggu verifikasi dari pihak JuraganCOD

!> Pastikan <b><i>nomor telefon</b></i> dan <b><i>e-mail</b></i> yang anda gunakan aktif sebagai pengiriman OTP
## Verivikasi untuk Akun anda
## Membuka setting
## Open API Key
    <!DOCTYPE html>
    <html lang="en">
    <head>
