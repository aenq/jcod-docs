<!-- docs/_sidebar.md -->

* [Cara Mendaftar API ke JuraganCOD](daftarapi.md)
* [Cara Menggunakan API sebagai Pengiriman Satuan](kirimsatuan.md)
* [Cara Menggunakan API sebagai Pengiriman Massal](kirimmassal.md)
